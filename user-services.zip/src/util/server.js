module.exports = {
    port: process.env.PORT || 1801,
    secreKeyExpress: process.env.KEYEXPRESS || 'COSTAPP',
    secreKeyPassport: process.env.KEYPASSPORT ||'COSTAPP'
}